document.addEventListener('DOMContentLoaded', function() {
    const queryString = window.location.search;
    const urlParams = new URLSearchParams(queryString);
    const data = JSON.parse(decodeURIComponent(urlParams.get('data')));
  
    const bookingDetailsContainer = document.getElementById('booking-details');
    if (data && data.length > 0) {
      data.forEach(booking => {
        const bookingElement = document.createElement('div');
        bookingElement.innerHTML = `
          <p>Name: ${booking.name}</p>
          <p>Phone: ${booking.phone}</p>
          <p>Person: ${booking.person}</p>
          <p>Reservation Date: ${booking.reservationDate}</p>
          <p>Reservation Time: ${booking.reservationTime}</p>
          <p>Message: ${booking.message}</p>
        `;
        bookingDetailsContainer.appendChild(bookingElement);
      });
    } else {
      bookingDetailsContainer.textContent = 'No booking data available';
    }
});
