// Import Firebase services
import { initializeApp } from "https://www.gstatic.com/firebasejs/9.6.10/firebase-app.js";
import { getFirestore, collection, addDoc ,getDocs} from "https://www.gstatic.com/firebasejs/9.6.10/firebase-firestore.js";


const firebaseConfig = {
  apiKey: "AIzaSyCV0htRpkBUM_nMR-NVlYwkBN4gMJWiD64",
  authDomain: "food-flow-4f590.firebaseapp.com",
  projectId: "food-flow-4f590",
  storageBucket: "food-flow-4f590.appspot.com",
  messagingSenderId: "407610987375",
  appId: "1:407610987375:web:fdea58ef02fe95af6cce9a",
  measurementId: "G-TQN5FTSMPL"
};


'use strict';



/**
 * PRELOAD
 * 
 * loading will be end after document is loaded
 */

const preloader = document.querySelector("[data-preaload]");

window.addEventListener("load", function () {
  preloader.classList.add("loaded");
  document.body.classList.add("loaded");
});



/**
 * add event listener on multiple elements
 */

const addEventOnElements = function (elements, eventType, callback) {
  for (let i = 0, len = elements.length; i < len; i++) {
    elements[i].addEventListener(eventType, callback);
  }
}



/**
 * NAVBAR
 */

const navbar = document.querySelector("[data-navbar]");
const navTogglers = document.querySelectorAll("[data-nav-toggler]");
const overlay = document.querySelector("[data-overlay]");

const toggleNavbar = function () {
  navbar.classList.toggle("active");
  overlay.classList.toggle("active");
  document.body.classList.toggle("nav-active");
}

addEventOnElements(navTogglers, "click", toggleNavbar);



/**
 * HEADER & BACK TOP BTN
 */

const header = document.querySelector("[data-header]");
const backTopBtn = document.querySelector("[data-back-top-btn]");

let lastScrollPos = 0;

const hideHeader = function () {
  const isScrollBottom = lastScrollPos < window.scrollY;
  if (isScrollBottom) {
    header.classList.add("hide");
  } else {
    header.classList.remove("hide");
  }

  lastScrollPos = window.scrollY;
}

window.addEventListener("scroll", function () {
  if (window.scrollY >= 50) {
    header.classList.add("active");
    backTopBtn.classList.add("active");
    hideHeader();
  } else {
    header.classList.remove("active");
    backTopBtn.classList.remove("active");
  }
});



/**
 * HERO SLIDER
 */

const heroSlider = document.querySelector("[data-hero-slider]");
const heroSliderItems = document.querySelectorAll("[data-hero-slider-item]");
const heroSliderPrevBtn = document.querySelector("[data-prev-btn]");
const heroSliderNextBtn = document.querySelector("[data-next-btn]");

let currentSlidePos = 0;
let lastActiveSliderItem = heroSliderItems[0];

const updateSliderPos = function () {
  lastActiveSliderItem.classList.remove("active");
  heroSliderItems[currentSlidePos].classList.add("active");
  lastActiveSliderItem = heroSliderItems[currentSlidePos];
}

const slideNext = function () {
  if (currentSlidePos >= heroSliderItems.length - 1) {
    currentSlidePos = 0;
  } else {
    currentSlidePos++;
  }

  updateSliderPos();
}

heroSliderNextBtn.addEventListener("click", slideNext);

const slidePrev = function () {
  if (currentSlidePos <= 0) {
    currentSlidePos = heroSliderItems.length - 1;
  } else {
    currentSlidePos--;
  }

  updateSliderPos();
}

heroSliderPrevBtn.addEventListener("click", slidePrev);

/**
 * auto slide
 */

let autoSlideInterval;

const autoSlide = function () {
  autoSlideInterval = setInterval(function () {
    slideNext();
  }, 7000);
}

addEventOnElements([heroSliderNextBtn, heroSliderPrevBtn], "mouseover", function () {
  clearInterval(autoSlideInterval);
});

addEventOnElements([heroSliderNextBtn, heroSliderPrevBtn], "mouseout", autoSlide);

window.addEventListener("load", autoSlide);



/**
 * PARALLAX EFFECT
 */

const parallaxItems = document.querySelectorAll("[data-parallax-item]");

let x, y;

window.addEventListener("mousemove", function (event) {

  x = (event.clientX / window.innerWidth * 10) - 5;
  y = (event.clientY / window.innerHeight * 10) - 5;

  // reverse the number eg. 20 -> -20, -5 -> 5
  x = x - (x * 2);
  y = y - (y * 2);

  for (let i = 0, len = parallaxItems.length; i < len; i++) {
    x = x * Number(parallaxItems[i].dataset.parallaxSpeed);
    y = y * Number(parallaxItems[i].dataset.parallaxSpeed);
    parallaxItems[i].style.transform = `translate3d(${x}px, ${y}px, 0px)`;
  }

});
// document.addEventListener('DOMContentLoaded', function() {
//   // Your code here
//   const reservationTime = document.querySelector('select[name="reservation-time"]');
//   if (reservationTime) {
//     // Call the function when the form is submitted
//     document.querySelector('.reservation-form').addEventListener('submit', function(event) {
//       event.preventDefault(); // Prevent form submission
//       uploadReservationData(); // Upload reservation data to Firestore
//     });
//   } else {
//     console.error('Select element with name "reservation-time" not found');
//   }
// });

// Initialize Firebase app
const app = initializeApp(firebaseConfig);

// Get a reference to the Firestore service
const db = getFirestore(app);

// Function to upload reservation data to Firestore
async function uploadReservationData() {
  // Get form elements
  const name = document.querySelector('input[name="name"]').value;
  const phone = document.querySelector('input[name="phone"]').value;
  const person = document.querySelector('select[name="person"]').value;
  const reservationDate = document.querySelector('input[name="reservation-date"]').value;
  const reservationTime = document.querySelector('select[name="reservation-time"]').value;
  const message = document.querySelector('textarea[name="message"]').value;

  // Add data to Firestore
  try {
    await addDoc(collection(db, "reservations"), {
      name: name,
      phone: phone,
      person: person,
      reservationDate: reservationDate,
      reservationTime: reservationTime,
      message: message
    });

    // After successfully uploading data, fetch booking data from Firestore and navigate to booking.html
    fetchBookingDataAndNavigate();
  } catch (error) {
    console.error("Error writing document: ", error);
    alert("Error uploading reservation data: " + error);
  }
}

// Function to fetch booking data from Firestore and navigate to booking.html
async function fetchBookingDataAndNavigate() {
  try {
    const querySnapshot = await getDocs(collection(db, "reservations"));
    const bookingData = querySnapshot.docs.map(doc => doc.data());
    const encodedData = encodeURIComponent(JSON.stringify(bookingData));
    window.location.href = `booking.html?data=${encodedData}`;
  } catch (error) {
    console.error("Error fetching booking data:", error);
    // Handle error if needed
  }
}

// Call the function when the form is submitted
document.querySelector('.reservation-form').addEventListener('submit', function(event) {
  event.preventDefault(); // Prevent form submission
  uploadReservationData(); // Upload reservation data to Firestore
});
