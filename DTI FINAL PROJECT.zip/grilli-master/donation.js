document.addEventListener('DOMContentLoaded', function() {
    // Get reference to the form element
    const form = document.getElementById('241093087863462'); // Update with your form ID

    // Add event listener for form submission
    form.addEventListener('submit', async (e) => {
        e.preventDefault(); // Prevent the default form submission

        // Get form data
        const formData = new FormData(form);

        // Convert FormData to JSON object
        const data = {};
        formData.forEach((value, key) => {
            data[key] = value;
        });

        // Store data in Firestore
        try {
            const response = await fetch('https://console.firebase.google.com/u/0/project/food-flow-4f590/firestore/databases/-default-/data/~2FDonations~2FDonation', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(data),
            });
            if (response.ok) {
                console.log('Data stored successfully in Firestore');
                // Optionally, reset the form after successful submission
                form.reset();
            } else {
                console.error('Failed to store data in Firestore');
            }
        } catch (error) {
            console.error('Error storing data in Firestore:', error);
        }
    });
});
